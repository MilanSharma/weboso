#!/usr/bin/env python
 

print
print "<title>Test CGI</title>"


# Import modules 
import cgi, cgitb 
import csv
import webbrowser
import subprocess
import sqlite3

apprun = './capture_picture.py'

conn = sqlite3.connect('oso.db')

# Create instance of FieldStorage 
form = cgi.FieldStorage() 

# Get data from fields
username = form.getvalue('username')
password = form.getvalue('password')


users = []
userlist = []
passwordlist = []


cursor = conn.execute("SELECT id, name, password  from COMPANY")
for row in cursor:
   users.append(row)


for i in range(len(users)):
	userlist.append(users[i][1])
	passwordlist.append(users[i][2])


if username in userlist:
    index = userlist.index(username)
    if passwordlist[index] == password:
	#print "Welcome to oso!!"
	url = 'http://localhost:9990/all/frame.html'
	webbrowser.open(url, new=0)
        subprocess.call(apprun)        
    else:
	print "Incorret Password!!"
else:
    print "Invalid Username!!"


conn.close()



