#!/bin/sh
cd $(dirname $0)
BASE=`dirname $0`
python $BASE/base.py

