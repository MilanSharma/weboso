#!/usr/bin/env python
 

print
print "<title>OSO Tree</title>"
print "<meta http-equiv = 'Content-Type' content='text/html; charset=utf-8'"

print "<button onClick='logout' style='float:right'>Logout</button>"

import os
import subprocess

rootdir = "./AllExeContent"





def traverse(dir):
    print '<ul>'
    for item in os.listdir(dir):
        print '<li>%s</li>' % item
        fullpath = os.path.join(dir, item)
	indexfile = fullpath+"/index.html"
	checkIndex = os.path.isfile(indexfile)
        if os.path.isdir(fullpath):
            traverse(fullpath)
    print '</ul>'

projectdir = './AllExeContent'
traverse(projectdir)












