#!/usr/bin/env python

import os 
import subprocess
import webbrowser
import threading

apprun = './server.py'
new = 'http:localhost:9990/'



class myThread (threading.Thread):
    def __init__(self, threadID, app):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.apprun = apprun
        
    def run(self):
        subprocess.call(self.apprun)
        subprocess.call(self.url)
        

thread1 = myThread(1, apprun)
thread2 = myThread(2, [webbrowser.open(new)])




thread1.start()
thread2.start()
